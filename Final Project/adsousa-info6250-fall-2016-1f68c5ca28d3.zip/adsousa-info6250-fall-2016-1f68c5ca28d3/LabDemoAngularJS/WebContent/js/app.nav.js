/**
 * 
 */

var app  = angular.module('navApp',['ngRoute','module.controllers']);

app.config(function($routeProvider) {
    $routeProvider

        // route for the home page
        .when('/dashboard', {
            templateUrl : 'partials/home.html',
            controller  : 'dashboardController',
            controllerAs: 'dashboardCtrl'
        })
        .when('/skill', {
            templateUrl : 'partials/skill.html',
            controller  : 'skillContoller',
            controllerAs: 'skillCtrl'
        })
        
        .when('/personal', {
            templateUrl : 'partials/personal.html',
            controller  : 'personalContoller',
            controllerAs: 'personalCtrl'
        })
        .otherwise({ redirectTo: '/dashboard' })
        ;
});

var controllers = angular.module('module.controllers', []);
controllers
.controller('dashboardController', function() {
	var dashboardCtrl = this;
	dashboardCtrl.messageDash = "This is Dashboard";
})
.controller('skillContoller', function($scope) {
	var skillCtrl = this;
	$scope.message = "This is skill";
	skillCtrl.message="This is fun";
	$scope.next = function(){
		
	};
})
.controller('personalContoller', function($scope) {
	$scope.message = "This is personal";

});
