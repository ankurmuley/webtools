package neu.edu.controller;

import java.util.Date;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

import org.springframework.stereotype.Controller;

@Controller
@Path("/echo")
public class EchoController {

	@GET
	public String getEcho() {
		return new Date().toString();
	}
}
