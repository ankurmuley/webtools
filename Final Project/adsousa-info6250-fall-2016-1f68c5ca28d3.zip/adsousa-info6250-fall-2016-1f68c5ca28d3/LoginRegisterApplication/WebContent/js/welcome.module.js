/**
 * 
 */
var welcomeModule = angular.module("welcome.module");
welcomeModule.controller('welcomeController', function() {
	
});