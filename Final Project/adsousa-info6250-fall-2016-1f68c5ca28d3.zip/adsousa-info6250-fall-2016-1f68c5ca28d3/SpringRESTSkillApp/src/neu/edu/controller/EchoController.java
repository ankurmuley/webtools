package neu.edu.controller;

import java.util.Date;

import javax.annotation.security.DenyAll;
import javax.annotation.security.PermitAll;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.jboss.resteasy.util.Base64;
import org.springframework.stereotype.Controller;

@Controller
@Path("/echo")
public class EchoController {

		@GET
		@PermitAll
		public String getEcho(){
			return new Date().toString()+"----";
		}
		
		
		
		@POST
		@Produces(MediaType.APPLICATION_JSON)
		public Response getAll(@QueryParam("name") String name) {
			return Response.ok().entity(new Object() {

				public String value = "";

				public String getValue() {
					return value;
				}

				public void setValue(String value) {
					this.value = value;
				}

				private Object init(String value) {
					this.value = value;
					return this;
				}

			}.init(name)).build();
		}
}
