package neu.edu.controller;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.springframework.stereotype.Controller;

import neu.edu.controller.model.Skill;
import neu.edu.controller.response.ErrorResponse;

@Path("/skill")
@Controller
@Consumes(MediaType.APPLICATION_JSON)
public class TestController {

	private Skill skill;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getSkill() {

		return Response.ok().entity(skill).build();
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Response addSkill(Skill request) {
		if (skill == null) {
			skill = request;
			return Response.ok().status(Status.OK).build();
		} else {
			ErrorResponse error = new ErrorResponse("skill-exists");
			return Response.ok().entity(error).status(error.status).build();		
		}

	}

	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateSkill(Skill request) {
		if (skill != null && request!=null) {
			skill = request;
			return Response.ok().status(Status.OK).build();
		} else if(skill != null) {
			ErrorResponse error = new ErrorResponse("skill-doesnt-exits");
			return Response.ok().entity(error).status(404).build();
		}else {
			ErrorResponse error = new ErrorResponse("update-failed");
			return Response.ok().entity(error).status(error.status).build();
		}

	}

	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteSkill(Skill request) {
		if (skill != null && request!=null) {
			skill = null;
			return Response.ok().status(Status.OK).build();
		} else {
			ErrorResponse error = new ErrorResponse("notting-delete");
			return Response.ok().entity(error).status(error.status).build();
		}
	}

}
