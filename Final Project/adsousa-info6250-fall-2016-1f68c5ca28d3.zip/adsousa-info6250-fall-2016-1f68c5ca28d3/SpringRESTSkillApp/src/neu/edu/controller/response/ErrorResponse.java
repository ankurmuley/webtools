package neu.edu.controller.response;

public class ErrorResponse {
	
	public static final int status = 422;
	
	private String msg;
	
	public ErrorResponse() {
		// TODO Auto-generated constructor stub
	}
	
	public ErrorResponse(String msg) {
		// TODO Auto-generated constructor stub
		this.msg = msg;
	}
	
	
	public String getMsg() {
		return msg;
	}
	
	public void setMsg(String msg) {
		this.msg = msg;
	}

}
