package neu.edu.controller.model;

public class Skill {
	
	private int java;
	private int cPlusPlus;
	private int maven;
	private int angular;
	
	
	
	public Skill(int java, int cPlusPlus, int maven, int angular) {
		super();
		this.java = java;
		this.cPlusPlus = cPlusPlus;
		this.maven = maven;
		this.angular = angular;
	}
	
	public Skill() {
		// TODO Auto-generated constructor stub
	}
	
	public int getJava() {
		return java;
	}
	public void setJava(int java) {
		this.java = java;
	}
	public int getcPlusPlus() {
		return cPlusPlus;
	}
	public void setcPlusPlus(int cPlusPlus) {
		this.cPlusPlus = cPlusPlus;
	}
	public int getMaven() {
		return maven;
	}
	public void setMaven(int maven) {
		this.maven = maven;
	}
	public int getAngular() {
		return angular;
	}
	public void setAngular(int angular) {
		this.angular = angular;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "[java="+java+",c++="+cPlusPlus+"]";
	}

}
