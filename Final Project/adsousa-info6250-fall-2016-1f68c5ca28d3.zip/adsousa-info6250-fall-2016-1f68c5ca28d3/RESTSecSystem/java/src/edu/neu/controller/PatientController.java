package edu.neu.controller;

import javax.annotation.security.DenyAll;
import javax.annotation.security.RolesAllowed;
import javax.validation.Valid;
import javax.websocket.server.PathParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.jboss.resteasy.spi.validation.ValidateRequest;
import org.springframework.stereotype.Controller;

import edu.neu.data.PatientData;



@Path("/user/{id}")
@Controller
@ValidateRequest
public class PatientController {

	
	@GET
	@POST
//	@RolesAllowed({"admin","customer"})
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/resturants")
	public Response createPatient(@Valid PatientData request,@PathParam("id") String id){
		
		return Response.ok().entity(request).build();
	}
}
