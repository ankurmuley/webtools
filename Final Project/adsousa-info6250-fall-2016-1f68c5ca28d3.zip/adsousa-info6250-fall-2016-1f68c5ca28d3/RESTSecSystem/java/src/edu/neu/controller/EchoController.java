package edu.neu.controller;

import java.util.Date;

import javax.annotation.security.DenyAll;
import javax.annotation.security.PermitAll;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import org.jboss.resteasy.util.Base64;
import org.springframework.stereotype.Controller;

@Controller
@Path("/echo")
public class EchoController {

		@GET
		@PermitAll
		public String getEcho(){
			return new Date().toString()+"----";
		}
		
		@GET
		@PermitAll
		@Path("/{key}")
		public String generateKey(@PathParam("key") String key){
			return Base64.encodeBytes(key.getBytes());
		}
}
