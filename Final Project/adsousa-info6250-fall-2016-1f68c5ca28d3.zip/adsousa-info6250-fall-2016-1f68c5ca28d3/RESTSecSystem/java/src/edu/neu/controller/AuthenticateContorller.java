package edu.neu.controller;

import java.util.Date;

import javax.annotation.security.PermitAll;
import javax.validation.Valid;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.log4j.Logger;
import org.jboss.resteasy.spi.validation.ValidateRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import edu.neu.data.AuthRequest;
import edu.neu.data.AuthResponse;
import edu.neu.data.AuthResponseError;
import edu.neu.data.UserSession;

@Controller
@ValidateRequest
@Path("/auth")
public class AuthenticateContorller {

	Logger log = Logger.getLogger(AuthenticateContorller.class);
	
//	@Autowired
//	private UserService userService;
	
	
 
	@POST
	@PermitAll
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAuthenticate(@Valid AuthRequest data) {
		log.debug("--" + data.getUsername() + "#" + data.getPassword());
		System.out.println(data.getUsername() + "#" + data.getPassword());
		
		
		//userService.validate()
		if(data.getUsername().equals("test") && data.getPassword().equals("test")){
			
			AuthResponse authResponse = new AuthResponse(new UserSession("12", data.getUsername(), "customer"));
			
			return Response.ok().status(200).entity(authResponse)
					.header("AUTH_KEY", "VALID").build();
		}else{
			AuthResponseError authResponseErr = new AuthResponseError();
			authResponseErr.setMessage("Invalid User");
			
			return Response.ok().status(422).entity(authResponseErr).build();
		}
			
			
		
		
	
	}

}
