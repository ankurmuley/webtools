package neu.edu.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import neu.edu.controller.data.RestLogicalErrorException;
import neu.edu.controller.data.UserSession;
import neu.edu.dao.UserDao;
import neu.edu.entity.User;

@Service
public class AuthenticationService {
	
	
	@Autowired
	private UserDao userDao;
	
	
	
	
	public UserSession validateUser(String username,String password) throws RestLogicalErrorException{
		
		User user = userDao.validateUser(username, password);
		
		UserSession userSession = null;
		
		if(user != null){
			
			userSession = new  UserSession();
			userSession.setId(String.valueOf(user.getId()));
			userSession.setName(user.getPerson().getFirstName()+" "+user.getPerson().getLastName());
			userSession.setRole(user.getRole());
			
		}else{
			RestLogicalErrorException authResponseErr = new RestLogicalErrorException("Invalid User");
			throw authResponseErr;
		}
		
		
		
		
		
		
		return userSession;
	}

}
