package neu.edu.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import neu.edu.controller.data.ResumeRequest;
import neu.edu.controller.data.ResumeResponse;
import neu.edu.dao.ResumeDao;
import neu.edu.entity.Resume;

@Service
public class ResumeService {
	
	@Autowired
	private ResumeDao resumeDao;
	
	
	public List<ResumeResponse> getResumeList(int userId){

		List<Resume> resumes = resumeDao.getResume(userId);
		List<ResumeResponse> resumeResponse = null;
		if (resumes != null) {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			resumeResponse = new ArrayList<>();
			for (Resume resume : resumes) {
				ResumeResponse response = new ResumeResponse(resume.getId(),
															resume.getName(), 
															resume.getDesc(), 
															sdf.format(resume.getCreationDate()));
				
				resumeResponse.add(response);
			}
		}
		return resumeResponse;
		
	}
	
	public boolean createResume(ResumeRequest resumeRequest,int userId){
	
		Resume resume = new Resume();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		if(resumeRequest.getCreationDate()!=null){
			try {
				resume.setCreationDate(sdf.parse(resumeRequest.getCreationDate()));
			} catch (ParseException e) {
				//DO NOTHING.
			}

		}
		
		resume.setDesc(resumeRequest.getDesc());
		resume.setName(resumeRequest.getName());

		
		return resumeDao.createResume(resume,userId);
		
	}

}
