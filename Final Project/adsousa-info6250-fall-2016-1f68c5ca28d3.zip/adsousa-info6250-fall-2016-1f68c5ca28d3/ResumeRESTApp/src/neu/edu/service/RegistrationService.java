package neu.edu.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import neu.edu.controller.data.RegistrationRequest;
import neu.edu.controller.data.RestLogicalErrorException;
import neu.edu.dao.UserDao;

@Service
public class RegistrationService {
	
	@Autowired
	private UserDao userDao;
	
	
	public boolean register(RegistrationRequest registrationRequest) throws RestLogicalErrorException{
		
		if(registrationRequest.getUsername() ==null ||
		   registrationRequest.getPassword() ==null){
			
			throw new RestLogicalErrorException("Registration Parameters incomplete.");
		}else{
			//Simulation a database Request
			if(!userDao.registrationCustomer(registrationRequest.getUsername(),
					registrationRequest.getPassword(),
					registrationRequest.getFirstName(),
					registrationRequest.getLastName(),
					registrationRequest.getEmail(),
					registrationRequest.getOccupationType(),
					registrationRequest.getTitle())){
				throw new RestLogicalErrorException("Duplicate User.");

			}
		}
		
		
		return true;
		
	}

}
