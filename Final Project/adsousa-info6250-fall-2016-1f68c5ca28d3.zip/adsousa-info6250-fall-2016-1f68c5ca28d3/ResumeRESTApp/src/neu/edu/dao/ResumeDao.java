package neu.edu.dao;

import java.util.Date;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Repository;

import neu.edu.business.Business;
import neu.edu.business.ConfigureABusiness;
import neu.edu.entity.Resume;
import neu.edu.entity.User;

@Repository
public class ResumeDao {

	private static Business business = ConfigureABusiness.getBusiness();
	
	public List<Resume> getResume(int userId){
		
		for(User user:business.getUsers()){
			if(user.getId() == userId){
				return user.getResumes();
			}
		}
		
		return null;
		
	}

	public boolean createResume(Resume resume,int userId) {
		// TODO Auto-generated method stub
		for(User user:business.getUsers()){
			if(user.getId() == userId){
				//Since Simulator ignoring checking duplicate Resume ID for user.
				resume.setId(new Random().nextInt(100));
				if(resume.getCreationDate() ==null){
					resume.setCreationDate(new Date());
				}
				user.addResume(resume);
				return true;
			}
		}
		return false;
	}
	
		
}
