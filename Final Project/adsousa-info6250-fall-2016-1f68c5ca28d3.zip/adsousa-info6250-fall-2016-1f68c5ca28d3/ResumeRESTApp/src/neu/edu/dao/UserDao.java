package neu.edu.dao;

import java.util.Random;

import org.springframework.stereotype.Repository;

import neu.edu.business.Business;
import neu.edu.business.ConfigureABusiness;
import neu.edu.entity.Person;
import neu.edu.entity.User;

@Repository
public class UserDao {

	private static Business business = ConfigureABusiness.getBusiness();

	public User validateUser(String username, String password) {

		for (User user : business.getUsers()) {
			if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
				return user;
			}
		}
		return null;
	}

	public boolean registrationCustomer(String username, String password, String firstName, String lastName, String email, String occupationType,
			String title) {

		User userTemp = new User();
		userTemp.setId(new Random().nextInt(100000));
		userTemp.setPassword(password);
		userTemp.setUsername(username);
		userTemp.setRole("customer");

		Person person = new Person();
		person.setEmail(email);
		person.setOccupationType(occupationType);
		person.setTitle(title);
		person.setFirstName(firstName);
		person.setLastName(lastName);

		userTemp.setPerson(person);

		for (User user : business.getUsers()) {
			if (user.getUsername().equals(userTemp.getUsername()) && user.getPassword().equals(userTemp.getPassword())) {
				return false;
			}
		}

		business.addUser(userTemp);

		return true;
	}

}
