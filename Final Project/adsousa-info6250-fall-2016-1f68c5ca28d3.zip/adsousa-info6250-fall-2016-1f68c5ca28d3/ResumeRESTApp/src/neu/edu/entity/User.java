package neu.edu.entity;

import java.util.ArrayList;
import java.util.List;

public class User {
	
	private int id;
	private Person person;
	private String role;
	private String username;
	private String password;
	private List<Resume> resumes = new  ArrayList<>();
	
	
	public User() {
		// TODO Auto-generated constructor stub
	}
	
	public Person getPerson() {
		return person;
	}
	
	public void setPerson(Person person) {
		this.person = person;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Resume> getResumes() {
		return resumes;
	}

	public void setResumes(List<Resume> resumes) {
		this.resumes = resumes;
	}
	
	public void addResume(Resume resume){
		resumes.add(resume);
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	

}
