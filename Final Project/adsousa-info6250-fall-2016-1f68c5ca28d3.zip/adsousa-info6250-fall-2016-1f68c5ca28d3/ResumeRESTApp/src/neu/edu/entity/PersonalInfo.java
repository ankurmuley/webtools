package neu.edu.entity;

public class PersonalInfo {
	
	private String objective;
	
	public String getObjective() {
		return objective;
	}
	
	public void setObjective(String objective) {
		this.objective = objective;
	}


}
