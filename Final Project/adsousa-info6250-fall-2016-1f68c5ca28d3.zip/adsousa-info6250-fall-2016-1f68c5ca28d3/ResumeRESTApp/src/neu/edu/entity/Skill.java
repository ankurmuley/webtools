package neu.edu.entity;

public class Skill {
	
	private int java;
	private int cPlus;
	
	public int getcPlus() {
		return cPlus;
	}
	
	public void setcPlus(int cPlus) {
		this.cPlus = cPlus;
	}
	
	public int getJava() {
		return java;
	}
	
	public void setJava(int java) {
		this.java = java;
	}

}
