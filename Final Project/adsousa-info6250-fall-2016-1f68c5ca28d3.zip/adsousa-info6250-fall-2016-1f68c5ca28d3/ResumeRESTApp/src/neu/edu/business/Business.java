package neu.edu.business;

import java.util.ArrayList;
import java.util.List;

import neu.edu.entity.User;

public class Business {
	
	private List<User> users = new ArrayList<>();
	
	
	public List<User> getUsers() {
		return users;
	}
	
	public void addUser(User user){
		users.add(user);
	}
	

}
