package neu.edu.business;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import neu.edu.entity.Person;
import neu.edu.entity.Resume;
import neu.edu.entity.User;

public class ConfigureABusiness {
	
	private static Business business = new Business();
	
	
	static {
		
		Person person = new Person();
		person.setFirstName("Ashwin");
		person.setLastName("DSousa");
		person.setEmail("a@a.com");
		person.setOccupationType("IT");
		person.setTitle("Mr");
		person.setDateOfBirth(new Date());
		
	    Random randomGenerator = new Random();

		User user = new User();
		user.setId(randomGenerator.nextInt(100000));
		user.setUsername("ashwin");
		user.setPassword("password");
		user.setRole("customer");
		user.setPerson(person);
		
		
		Resume resume;
		
		resume = new Resume();
		resume.setId(randomGenerator.nextInt(100));
		resume.setName("First Resume");
		resume.setDesc("The is first Resume");
		resume.setCreationDate(new Date());
		
		user.addResume(resume);
		
		resume = new Resume();
		resume.setId(randomGenerator.nextInt(100));
		resume.setName("Second Resume");
		resume.setDesc("The is first Resume");
		resume.setCreationDate(new Date());
		
		user.addResume(resume);
		
		
		business.addUser(user);
		
	}
	
	public static Business getBusiness() {
		return business;
	}

}
