package neu.edu.controller.data;

import java.util.Date;

import neu.edu.entity.PersonalInfo;
import neu.edu.entity.Skill;

public class ResumeRequest {
	
	private String name;
	private String desc;
	private String creationDate;
	
	
	
	
	public ResumeRequest() {
		// TODO Auto-generated constructor stub
	}


	


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDesc() {
		return desc;
	}


	public void setDesc(String desc) {
		this.desc = desc;
	}


	public String getCreationDate() {
		return creationDate;
	}


	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	
	

}
