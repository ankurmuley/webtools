
package neu.edu.controller;

import java.util.Date;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

import org.springframework.stereotype.Controller;

@Controller
@Path("/echo")
public class EchoController {
	
	@GET
	public String getDate(@QueryParam("msg") String msg){
		return new Date().toString() + ";msg="+msg;
		
	}

}
