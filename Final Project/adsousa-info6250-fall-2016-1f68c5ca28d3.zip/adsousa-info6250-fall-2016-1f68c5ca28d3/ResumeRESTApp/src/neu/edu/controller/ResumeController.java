package neu.edu.controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import neu.edu.controller.data.ResponseError;
import neu.edu.controller.data.ResumeRequest;
import neu.edu.controller.data.ResumeResponse;
import neu.edu.entity.Resume;
import neu.edu.service.ResumeService;

@Path("/user/{id}")
@Controller
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ResumeController {

	@Autowired
	private ResumeService resumeService;

	@GET
	@Path("/resume")
	public Response getResume(@PathParam("id") String id) {

		List<ResumeResponse> resumes = null;
		try {
			resumes = resumeService.getResumeList(Integer.parseInt(id));

		} catch (NumberFormatException ex) {
			return Response.ok().status(422).entity(new ResponseError("Invalid UserId Format")).build();
		}

		if (resumes == null) {
			return Response.ok().status(422).entity(new ResponseError("Resume Not Found")).build();

		}
		return Response.ok().entity(resumes).build();

	}

	@POST
	@Path("/resume")
	public Response addResume(@PathParam("id") String id,ResumeRequest request) {
		boolean flag = false;
		try {
			flag = resumeService.createResume(request, Integer.parseInt(id));
		} catch (NumberFormatException ex) {
			return Response.ok().status(422).entity(new ResponseError("Invalid UserId Format")).build();
		}
		
		if(flag){
			return Response.ok().build();
		}else{
			return Response.ok().status(422).entity(new ResponseError("Resume Creation Failed")).build();

		}

	}

}
